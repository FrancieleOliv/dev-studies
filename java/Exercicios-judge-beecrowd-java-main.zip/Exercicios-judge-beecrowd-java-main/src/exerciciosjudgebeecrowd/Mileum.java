package exerciciosjudgebeecrowd;

import java.util.Scanner;

public class Mileum {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int A, B;
		A = sc.nextInt();
		B = sc.nextInt();		
		System.out.println("X = "+ (A + B));
		
		sc.close();
	}

}
